## Preview UWP support for .NET 9 XAML Compiler (Windows SDK 10.0.26100.0)

This bundle contains the preview XAML Compiler to use with UWP .NET 9 apps.
It is part of a servicing update of the Windows 10.0.26100.0 SDK.
For more info, see: https://aka.ms/preview-uwp-support-for-dotnet9.

### Instructions

In order to build UWP for .NET projects using XAML, you'll need to copy these two files:
- **Microsoft.Windows.UI.Xaml.Build.Tasks.dll**: copy to `C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\XamlCompiler`
- **Microsoft.Windows.UI.Xaml.Common.targets**: copy to `C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\XamlCompiler`

These instructions assume that the Windows 10.0.26100.0 SDK is already installed.
If not, you can download it from: https://developer.microsoft.com/windows/downloads/windows-sdk/.

See the LICENSE file included in this bundle for additional license terms information.
You can also find the same license at: https://aka.ms/WinSDKPreviewLicenseURL.